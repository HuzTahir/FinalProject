import './App.css';
import React from 'react';
import { useState } from 'react';
import { useRoutes } from 'react-router-dom'
import { Link } from 'react-router-dom'
import Home from './pages/Home';
import CreatePost from './pages/CreatePost';
import ViewPost from './pages/ViewPost';
import UpdatePost from './pages/UpdatePost';


const App = () => {

  const [searchQuery, setSearchQuery] = useState(''); // State for search query

  // Update the search query based on input change
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };
  
  // Sets up routes
  let element = useRoutes([
    {
      path: "/",
      element:<Home searchQuery={searchQuery}/>
    },
    {
      path:"/new",
      element: <CreatePost/>
    },
    {
      path:"/posts/:id",
      element: <ViewPost />
    },
    {
      path:"/update/:id",
      element: <UpdatePost />
    }
    
  ]);

  return ( 
<>
    <div className="App">

      <div className="navbar">
        <h3>CommentsHub</h3>
        <input
            type="text"
            id="search"
            placeholder="Search posts by title"
            value={searchQuery}
            onChange={handleSearchChange}
          />
        <ul>
          <Link to="/"><li>Home</li></Link>
          <Link to="/new"><li>Create new post</li></Link>
        </ul>
      </div>
    </div>
        {element}
</>
  );
}

export default App;
