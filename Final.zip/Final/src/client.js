import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://fnepxevocjrnkymkvuwm.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZuZXB4ZXZvY2pybmt5bWt2dXdtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzAzMjU2MjksImV4cCI6MjA0NTkwMTYyOX0.IaHvPWcTZoBrfIIi9MxjLvHy86nM_ar8yWSMOvlnyxk';
export const supabase = createClient(supabaseUrl, supabaseKey);