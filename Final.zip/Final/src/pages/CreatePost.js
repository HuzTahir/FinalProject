import React from 'react'
import { useState, useEffect } from 'react';
import { supabase } from '../client'
import "./CreatePost.css"

const CreatePost = () => {
    // State for each form field
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [videoUrl, setVideoUrl] = useState('');
    const [imageFile, setImageFile] = useState(null);

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImageFile(file);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        let imageUrl = '';
        if (imageFile) {
            const { data, error } = await supabase.storage
                .from('post-images')
                .upload(`public/${imageFile.name}`, imageFile);

            if (error) {
                console.error('Error uploading image:', error.message);
                return;
            } else {
                imageUrl = supabase.storage.from('post-images').getPublicUrl(`public/${imageFile.name}`).data.publicUrl;
            }
        }

        // Insert the post with image URL
        const { data, error } = await supabase
            .from('Posts')
            .insert([{ title, content, image_url: imageUrl, video_url: videoUrl }]);

        if (error) {
            console.error('Error creating post:', error.message);
        } else {
            console.log('Post created successfully:', data);
            // Reset form fields
            setTitle('');
            setContent('');
            setImageUrl('');
            setVideoUrl('');
            setImageFile(null);
        }
    };



    return (
        <div className='postcontainer'>


            <div className="create-post-form">
                {/* <h2>Create a New Post</h2> */}
                <form onSubmit={handleSubmit}>
                    {/* <label htmlFor="title">Title</label> */}
                    <input
                        type="text"
                        id="title"
                        value={title}
                        placeholder='Title'
                        onChange={(e) => setTitle(e.target.value)}
                        required
                    />

                    {/* <label htmlFor="content">Content (Optional)</label> */}
                    <textarea
                        id="content"
                        placeholder='Content (Optional)'
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                    />

                    {/* <label htmlFor="imageUrl">Image URL (Optional)</label> */}
                    <input
                        type="text"
                        id="imageUrl"
                        value={imageUrl}
                        placeholder='Image URL (Optional)'
                        onChange={(e) => setImageUrl(e.target.value)}
                    />
                    <input
                        type="text"
                        placeholder="Video URL (Optional)"
                        value={videoUrl}
                        onChange={(e) => setVideoUrl(e.target.value)}
                    />

                    <button type="submit">Create Post</button>
                </form>
            </div>
        </div>
    )
}

export default CreatePost
