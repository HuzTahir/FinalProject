import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../client';
import Spinner from '../components/Spinner';
import './Home.css';

const Home = ({ searchQuery }) => {
    const [posts, setPosts] = useState([]);
    const [sortOption, setSortOption] = useState('newest'); // State for sorting option

    // Function to fetch posts with sorting
    const fetchPosts = async (sortBy = 'newest') => {
        let query = supabase.from('Posts').select('*');

        // Apply sorting based on the selected option
        if (sortBy === 'newest') {
            query = query.order('created_at', { ascending: false });
        } else if (sortBy === 'mostPopular') {
            query = query.order('upvotes', { ascending: false });
        }

        const { data, error } = await query;

        if (error) {
            console.error('Error fetching posts:', error);
        } else {
            setPosts(data);
        }
    };

    useEffect(() => {
        fetchPosts(sortOption);
    }, [sortOption]); // Re-fetch posts when sort option changes

    // Filter posts based on search query
    const filteredPosts = posts.filter(post =>
        post.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (posts.length === 0) return <Spinner />;


    return (
        <>
            <div className="homecontainer">
                <div className="sorting-buttons">
                    <button
                        onClick={() => setSortOption('newest')}
                        className={sortOption === 'newest' ? 'active' : ''}
                    >
                        Newest
                    </button>
                    <button
                        onClick={() => setSortOption('mostPopular')}
                        className={sortOption === 'mostPopular' ? 'active' : ''}
                    >
                        Most Popular
                    </button>
                </div>

                {filteredPosts.length > 0 ? (
                    filteredPosts.map(post => (
                        <div key={post.id} style={{ border: '1px solid #ddd', padding: '16px', margin: '8px 0' }} className="home">
                            <p>Posted on: {new Date(post.created_at).toLocaleString()}</p>
                            <h2>{post.title}</h2>
                            {/* <p>{post.content ? post.content.slice(0, 100) + '...' : ''}</p> */}
                            <p>{post.upvotes} Upvotes</p>
                            <Link to={`/posts/${post.id}`}>View Full Post</Link>
                        </div>
                    ))
                ) : (
                    <p>No posts match your search.</p>
                )}
            </div>
        </>
    );
};

export default Home;
