import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../client';
import './UpdatePost.css'
import Spinner from '../components/Spinner';

const UpdatePost = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [loading, setLoading] = useState(true);
    const [videoUrl, setVideoUrl] = useState('');

    useEffect(() => {
        const fetchPost = async () => {
            const { data, error } = await supabase
                .from('Posts')
                .select('*')
                .eq('id', id)
                .single();

            if (error) {
                console.error("Error fetching post:", error);
            } else {
                setTitle(data.title);
                setContent(data.content);
                setImageUrl(data.image_url);
                setVideoUrl(data.video_url);
            }
            setLoading(false);
        };

        fetchPost();
    }, [id]);

    const handleUpdate = async (e) => {
        e.preventDefault();
        const { error } = await supabase
            .from('Posts')
            .update({ title, content, image_url: imageUrl, video_url: videoUrl })
            .eq('id', id);

        if (error) {
            console.error("Error updating post:", error);
        } else {
            navigate(`/posts/${id}`);
        }
    };

    if (loading) return <Spinner />;


    return (
        <>
            <div className='postcontainer'>
                <div className="update-post-form" style={{ padding: '20px' }}>
                    <h2>Update Post</h2>
                    <form onSubmit={handleUpdate}>
                        <input
                            type="text"
                            value={title}
                            placeholder="Title"
                            onChange={(e) => setTitle(e.target.value)}
                            required
                        />
                        <textarea
                            value={content}
                            placeholder="Content"
                            onChange={(e) => setContent(e.target.value)}
                        />
                        <input
                            type="text"
                            value={imageUrl}
                            placeholder="Image URL"
                            onChange={(e) => setImageUrl(e.target.value)}
                        />
                        <input
                            type="text"
                            placeholder="Video URL (Optional)"
                            value={videoUrl}
                            onChange={(e) => setVideoUrl(e.target.value)}
                        />
                        <button type="submit">Update Post</button>
                    </form>
                </div>
            </div>
        </>
    );
};

export default UpdatePost;
