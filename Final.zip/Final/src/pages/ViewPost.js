import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../client';
import { Link } from 'react-router-dom';
import './ViewPost.css';
import Spinner from '../components/Spinner';

const ViewPost = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [post, setPost] = useState(null);
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPost = async () => {
            const { data, error } = await supabase
                .from("Posts")
                .select('*')
                .eq('id', id)
                .single();
            if (error) {
                console.error("Error fetching post:", error);
            } else {
                setPost(data);
            }
            setLoading(false);
        };

        const fetchComments = async () => {
            const { data, error } = await supabase
                .from("Comments")
                .select('*')
                .eq('post_id', id)
                .order('created_at', { ascending: true });
            if (error) {
                console.error("Error fetching comments:", error);
            } else {
                setComments(data);
            }
        };

        fetchPost();
        fetchComments();
    }, [id]);

    const handleUpvote = async () => {
        if (post) {
            const newUpvoteCount = (post.upvotes || 0) + 1;
            const { error } = await supabase
                .from('Posts')
                .update({ upvotes: newUpvoteCount })
                .eq('id', id);

            if (error) {
                console.error('Error updating upvotes:', error);
            } else {
                setPost(prevPost => ({
                    ...prevPost,
                    upvotes: newUpvoteCount
                }));
            }
        }
    };

    const handleDelete = async () => {
        const { error } = await supabase
            .from('Posts')
            .delete()
            .eq('id', id);

        if (error) {
            console.error("Error deleting post:", error);
        } else {
            navigate('/');
        }
    };

    const handleAddComment = async (e) => {
        e.preventDefault();
        if (newComment.trim() === "") return;

        const { data, error } = await supabase
            .from("Comments")
            .insert([{ content: newComment, post_id: id }])
            .select(); // Use select() to return the newly added comment

        if (error) {
            console.error("Error adding comment:", error);
        } else {
            setComments((prevComments) => [...prevComments, data[0]]); // Append the new comment
            setNewComment("");
        }
    };

    const getEmbeddableUrl = (url) => {
        if (url.includes("youtube.com/watch")) {
            return url.replace("watch?v=", "embed/");
        }
        // Add additional cases for other platforms if needed.
        return url;
    };



    if (loading) return <Spinner />;
    if (!post) return <p>Post not found</p>;

    return (
        <div className="viewcontainer">
            <div className="viewpost">
                <p>Posted {new Date(post.created_at).toLocaleString()}</p>
                <h1>{post.title}</h1>
                <p>{post.content}</p>
                {post.image_url && (
                    <img
                        src={post.image_url}
                        alt={post.title}
                        style={{ maxWidth: '100%', height: 'auto' }}
                    />
                )}
                {post.video_url && (
                    <iframe
                        src={getEmbeddableUrl(post.video_url)}
                        title="Video"
                        width="100%"
                        height="400"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                    ></iframe>
                )}
                <p>
                    <span role="img" aria-label="thumbs up">
                        👍
                    </span>{" "}
                    {post.upvotes || 0} upvotes
                </p>
                <div className="buttons">
                    <button onClick={handleUpvote} className="upvote-button">
                        <img src="/thumbs-up.png" alt="Upvote" />
                        Upvote
                    </button>
                    <button onClick={handleDelete} className="delete-button">
                        Delete Post
                    </button>
                    <Link to={`/update/${post.id}`} className="link-button">
                        Update Post
                    </Link>
                </div>

                {/* Comments Section */}
                <div className="comments-section">
                    <h3>Comments</h3>
                    <ul className="comments-list">
                        {comments.map((comment) => (
                            <li key={comment.id} className="comment">
                                - {comment.content}
                            </li>
                        ))}
                    </ul>
                    <form onSubmit={handleAddComment} className="comment-form">
                        <input
                            type="text"
                            placeholder="Leave a comment..."
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            className="comment-input"
                        />
                        <button type="submit" className="comment-button">Post</button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default ViewPost;
